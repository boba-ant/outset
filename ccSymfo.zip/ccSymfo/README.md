#Question_1 -Version0:

#Question_2 -Version1:
#Créer une nouvelle enité avec la commande :
php bin/console make:entity
#Créer la table 
php bin/console make:migration

#Question_3 -Version2:
#Créer une base de donnée 
php bin/console doctrine:database:create

#Question_4 - Version3:
#Creation d'une Fixture
php bin/console make:fixture
#Créer une fixture lancer la commande:
php bin/console make:migrations:migrate #ensuite modifier le fichier créé
#commande fournissant la "DoctrineFixturesBundle" est installé  comme suit:
composer require doctrine/doctrine-fixtures-bundle --dev
#Charger les données dans la table:
php bin/console doctrine:fixtures:load --no-interaction

#Question_5 -Version4:
#Créer un controlleur :
php bin/console make:controller
#Pour créer automatiquement un formulaire :
php bin/console make:form

#pour ajouter une relation entre les deux entités:
Choisir la collection de l'entité en question, ensuite en fonction des relations : OneToMany, ManyToOne, OneToOne, ManyToMany

#Question_8 -Version7:
#Classes et Interfaces données par l'autowiring
php bin/console debug:autowiring --all
#Pour avoir le format Markdown:
-installer avec le composer notre Markdown avec la commande :
composer require cebe/markdown
Ensuite modifier la Classe Controller pour rajouter un parser de type Markdown, mais surtout préciser le nouveau service
dans notre dossier config/dans le fichier services.yaml qui est aussi une Classe

#Commande permettant d'installer le serveur en mode dévellopement:
composer require server --dev
#Pour lancer le serveur ensuite, il suffit de faire:
php bin/console server:run
#Pour l'installation des fakers:
composer require fzaninotto/faker --dev




