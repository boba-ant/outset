<?php

namespace App\Controller;

use App\Entity\Cours;
use App\Entity\Semestre;
use App\Form\CoursType;
use App\Repository\CoursRepository;
use App\Repository\SemestreRepository;
use cebe\markdown\Markdown;
use Doctrine\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class CoursController extends AbstractController
{
    /**
     * @Route("/cours", name="cours_index", methods={"GET"})
     */
    public function index(CoursRepository $repo)
    {
        $cours= $repo->findAll();

        return $this->render('cours/index.html.twig', [
            'controller_name' => 'CoursController',
            'cours' => $cours
        ]);
    }

    /**
     * @Route("/", name="home")
     */

    public function home(){
        return $this->render('cours/home.html.twig', [
            'title' => "Bienvenu dans mes cours !"
        ]);

    }
    /**
     * @Route("/cours/new", name="cours_create")
     */
    public function create(Request $request)
    {
            $cours = new Cours();

        $form = $this->createForm(CoursType::class, $cours);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()){
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($cours);
            $entityManager->flush();

            return $this->redirectToRoute('cours_show', ['id' => $cours->getId()]);
        }

        return $this->render('cours/create.html.twig', [
            'formCours' => $form->createView(),
        ]);
    }

    /**
     * @Route("/cours/{id}/edit/", name="cours_edit")
     */
    public function edit(Request $request, Cours $cour)
    {
        $form = $this->createForm(CoursType::class, $cour);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('cours_index');
        }

        return $this->render('cours/edit.html.twig', [
            'cour' => $cour,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/cours/{id}", name="cours_show")
     */
    public function show(Cours $cours, Markdown $parser)
    {
        $parsedCours = [];

        foreach ($cours as $cours){
            $parsedCours[] = [
                'nom' => $cours->getNom(),
                 'description' =>$parser ->parse( $cours->getDescription()),
                 'semestre' =>$cours->getSemestre()

            ];
        }
        dd($parsedCours);

        return $this->render('cours/show.html.twig',[
            'cour' => $cours
        ]);
    }

    /**
     * @Route("/cours/{id}/delete/", name="cours_delete")
     */
    public function delete(Request $request, Cours $cour, CoursRepository $coursRepo)
    {
        //($this->isCsrfTokenValid('delete'.$cour->getId(), $request->request->get('_token')))
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($cour);
            $entityManager->flush();

            $cours = $coursRepo ->findAll();

        return $this->render('cours/index.html.twig',[
            'cours'=> $cours
        ]);
    }

}
