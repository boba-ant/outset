<?php

namespace App\DataFixtures;

use App\Entity\Cours;
use App\Entity\Semestre;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class CoursFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        $faker = \Faker\Factory::create('fr_FR');
        for($j=1; $j <=3; $j++) {
            $semestre = new Semestre();
            $semestre->setNomSemestre($faker->word());
            $semestre->setFormation($faker->word());


            for ($i = 1; $i <= 3; $i++) {
                $cours = new Cours();
                $cours->setNom($faker->word());
                $cours->setDescription($faker->sentence());
                $cours->setSemestre($semestre);

                $manager->persist($cours);
            }
            $semestre->addCour($cours);

            $manager->persist($semestre);

        }

        $manager->flush();
    }
}
